#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>

main(){
	setlocale(LC_ALL, "Portuguese");
	int menor, *vetor, tam, i, aux, j, numN;
	menor = 0; //1
	aux = 0; //1
	printf("Informe o tamanho do vetor: "); //n
	scanf("%d", &tam); //0
	vetor = (int*) malloc( sizeof(int*) *tam); //1
    for(i=0; i<tam; i++){ //n
    	printf("Informe n�meros inteiros: "); //1
		scanf("%d", &vetor[i]); //0
		if(i==0){menor=vetor[i];} //1
		if(vetor[i]<menor){ //n
			menor = vetor[i]; //n
		}
	}
	for(i=0;i<tam;i++){ //n
		for(j=0;j<tam;j++){ //n
			if(vetor[i]<vetor[j]){ //n
				aux = vetor[i]; //n
				vetor[i] = vetor[j]; //n
				vetor[j] = aux; //n
			}
		}
	}
	for(i=0;i<tam;i++){ //n
		printf("Vetor Ordenado : %d\n", vetor[i]); //1
	}
	printf("Informe um n�mero: "); //1
	scanf("%d", &numN); //0
    for(i=0;i<tam;i++) { //n
        for (j=0;j<tam;j++) { //n
            if (numN<vetor[i]){ //n
                aux = vetor[i]; //n
                vetor[i] = numN; //n
                numN = aux; //n
            }
        }
    }
    for(i=0; i<tam; i++){ //n
    	if(i==0){menor=vetor[i];} //1
		if(vetor[i]<menor){ //n
			menor = vetor[i]; //n
		}
	}
	for(i=0;i<tam;i++){ //n
		printf("Vetor Ordenado : %d\n", vetor[i]); //1
	}
	printf("O menor valor do vetor � = %d", menor); //1
	Sleep(6000);
	//10+21n
}
