int Tarefas(int ativ, float multa, int temp, int temp1){
	int n, j, vet[];
	n = ativ;
	vet[] = 1;
	j = 1;
	do{
		for(i=2; i<=n; i++){
			if(temp>=temp1){
				vet[] = vet[]*vet[i];
				j=i;
			}
		}
	}while(i<=ativ && temp=temp1);
	return vet;
}
