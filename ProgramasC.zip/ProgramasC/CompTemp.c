//E: Sequencial a1,...,an com ai e [1,6]
//S: O n�mero de elementos tal que ai = 6

k =0;
for(i=0;i<n;i++){
	if(a[i] == 6)
		k++
}

//a) log2 4 = 2^2; P = 2%
//b) log2 0.25 = 2^-2; P = 0.25%
//c) log10 0.1 = 0,1; P = 0.1%
